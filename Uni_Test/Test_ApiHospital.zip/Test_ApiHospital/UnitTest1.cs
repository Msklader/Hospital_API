using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Hospital_API.Dtos;
using Hospital_API.Models;
using Hospital_API.Repositories;
using Hospital_API.Services;
using Moq;
using Xunit;

namespace Test_ApiHospital
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }

        [Fact]
        public async Task AlertaDeCancelaciones()
        {
            // Arrange: crear mock y configurar el m�todo para que no intente acceder a la BD.
            var mockRepo = new Mock<CitasRepository>(MockBehavior.Strict, null!);
            mockRepo.Setup(r => r.Verificar_Cancelaciones_Paciente(It.IsAny<int>()))
                .ReturnsAsync((int id) =>
                {
                    // Simular l�gica: para el paciente 2 devolvemos true (m�s de 3 cancelaciones en el �ltimo mes).
                    int cancelaciones_Ultimos30Dias = 3; // Simulamos que el paciente tiene 3 cancelaciones en los �ltimos 30 d�as.       

                    return cancelaciones_Ultimos30Dias >= 3;
                });

            var repo = mockRepo.Object;

            // Act
            bool alertaDeCancelaciones = await repo.Verificar_Cancelaciones_Paciente(2);

            // Assert
            Assert.IsType<bool>(alertaDeCancelaciones);
            Assert.True(alertaDeCancelaciones, "Se esperaba que el mock indicara que el paciente tiene m�s de 3 cancelaciones.");

            // Verificar que el m�todo fue invocado exactamente una vez con el par�metro esperado.
            mockRepo.Verify(r => r.Verificar_Cancelaciones_Paciente(2), Times.Once);
        }

        [Fact]
        public async Task AsignarHorario_InvalidTimeFormat_ReturnsFailure()
        {
            // Arrange
            var horarios = new List<Medico_HorariosDto>
            {
                new Medico_HorariosDto { Hora_Inicio = "25:00", Hora_Fin = "26:00" } // formato inv�lido
            };

            // Pasamos null al repo porque la validaci�n de formato ocurre antes de usar el repo
            var service = new MedicoService(null!);

            // Act
            var result = await service.AsignarHorario(1, horarios);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.Exito);
            Assert.Contains("formato", result.Mensaje, StringComparison.OrdinalIgnoreCase);
        }
    }
}