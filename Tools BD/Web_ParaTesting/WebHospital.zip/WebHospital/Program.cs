using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using WebHospital.Components;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();
builder.Services.AddHttpClient(); // opcional

// Register HttpClient para llamar a la API.
builder.Services.AddScoped(sp =>
    new HttpClient { BaseAddress = new Uri(builder.Configuration["ApiSettings:BaseUrl"] ?? "https://localhost:5001/") }
);

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

// A�adido: soporte anti-forgery (debe ir entre UseRouting() y los Map...)
// Si utilizas autenticaci�n/authorization, debe ir despu�s de UseAuthentication/UseAuthorization.
app.UseAntiforgery();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
