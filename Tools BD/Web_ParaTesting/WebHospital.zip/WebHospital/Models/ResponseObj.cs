﻿namespace WebHospital.Models
{
    public class ResponseObj<T>
    {
        public bool Exito { get; set; }
        public string Mensaje { get; set; }
        public T? Data { get; set; }
    }
}
